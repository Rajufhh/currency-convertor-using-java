import java.awt.*;
import javax.swing.*;

public class CurrencyConverterApp {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Currency Converter");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);

        currencyConverter applet = new currencyConverter();
        applet.init();
        applet.start();

        frame.add(applet, BorderLayout.CENTER);
        frame.setVisible(true);
    }
}
